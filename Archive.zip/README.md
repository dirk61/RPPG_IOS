#  AVMultiCamSession with SwiftUI

![Alt text](/Trois-cam/Preview%20Content/test.PNG?raw=true "Screenshot")
